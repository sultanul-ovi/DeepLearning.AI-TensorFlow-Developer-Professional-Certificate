Share your doubts and suggesions about the course.
