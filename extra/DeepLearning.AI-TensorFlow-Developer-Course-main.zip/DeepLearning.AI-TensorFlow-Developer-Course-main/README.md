# DeepLearning.AI-TensorFlow-Developer-Course       <a href="https://trackgit.com">
 
<img src="https://us-central1-trackgit-analytics.cloudfunctions.net/token/ping/km28c7uw39328ia9fgik" alt="trackgit-views" />
</a>


**[DeepLearning.AI TensorFlow Developer Professional Certificate](https://www.coursera.org/specializations/tensorflow-in-practice)**


**Instructor**: `Laurence Moroney`


All course Notebooks can be found [here](https://github.com/lmoroney/dlaicourse).

<kbd><img src="https://github.com/MaheshBabu11/DeepLearning.AI-TensorFlow-Developer-Course/blob/main/DeepLearning.AI%20TensorFlow%20Developer%20Course%20Certificate.png" /></kbd>

## Star History

<a href="https://star-history.com/#MaheshBabu11/DeepLearning.AI-TensorFlow-Developer-Course&Date">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/svg?repos=MaheshBabu11/DeepLearning.AI-TensorFlow-Developer-Course&type=Date&theme=dark" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/svg?repos=MaheshBabu11/DeepLearning.AI-TensorFlow-Developer-Course&type=Date" />
   <img alt="Star History Chart" src="https://api.star-history.com/svg?repos=MaheshBabu11/DeepLearning.AI-TensorFlow-Developer-Course&type=Date" />
 </picture>
</a>

## Stargazers

[![Stargazers repo roster for @MaheshBabu11/DeepLearning.AI-TensorFlow-Developer-Course](https://reporoster.com/stars/dark/MaheshBabu11/DeepLearning.AI-TensorFlow-Developer-Course)](https://github.com/MaheshBabu11/DeepLearning.AI-TensorFlow-Developer-Course/stargazers)
