# Graded Assignment - Quiz 3

<img src="../img/week3-quiz/1.PNG" alt="week-3-quiz">

<img src="../img/week3-quiz/2.PNG" alt="week-3-quiz">

<img src="../img/week3-quiz/3.PNG" alt="week-3-quiz">

<img src="../img/week3-quiz/4.PNG" alt="week-3-quiz">

<img src="../img/week3-quiz/5.PNG" alt="week-3-quiz">

<img src="../img/week3-quiz/6.PNG" alt="week-3-quiz">

<img src="../img/week3-quiz/7.PNG" alt="week-3-quiz">

<img src="../img/week3-quiz/8.PNG" alt="week-3-quiz">
