# Graded Assignment - Quiz 4

<img src="../img/week4-quiz/1.PNG" alt="week-4-quiz">

<img src="../img/week4-quiz/2.PNG" alt="week-4-quiz">

<img src="../img/week4-quiz/3.PNG" alt="week-4-quiz">

<img src="../img/week4-quiz/4.PNG" alt="week-4-quiz">

<img src="../img/week4-quiz/5.PNG" alt="week-4-quiz">

<img src="../img/week4-quiz/6.PNG" alt="week-4-quiz">

<img src="../img/week4-quiz/7.PNG" alt="week-4-quiz">

<img src="../img/week4-quiz/8.PNG" alt="week-4-quiz">
