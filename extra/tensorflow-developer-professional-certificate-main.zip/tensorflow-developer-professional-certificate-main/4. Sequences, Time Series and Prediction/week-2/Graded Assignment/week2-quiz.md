# Graded Assignment - Quiz 2

<img src="../img/week2-quiz/1.PNG" alt="week-2-quiz">

<img src="../img/week2-quiz/2.PNG" alt="week-2-quiz">

<img src="../img/week2-quiz/3.PNG" alt="week-2-quiz">

<img src="../img/week2-quiz/4.PNG" alt="week-2-quiz">

<img src="../img/week2-quiz/5.PNG" alt="week-2-quiz">

<img src="../img/week2-quiz/6.PNG" alt="week-2-quiz">

<img src="../img/week2-quiz/6 (1).PNG" alt="week-2-quiz">

<img src="../img/week2-quiz/6 (2).PNG" alt="week-2-quiz">

<img src="../img/week2-quiz/7.PNG" alt="week-2-quiz">

<img src="../img/week2-quiz/8.PNG" alt="week-2-quiz">

<img src="../img/week2-quiz/9.PNG" alt="week-2-quiz">