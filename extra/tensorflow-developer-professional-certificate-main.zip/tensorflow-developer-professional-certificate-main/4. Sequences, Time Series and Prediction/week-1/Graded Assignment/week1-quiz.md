# Graded Assignment - Quiz 1

<img src="../img/week1-quiz/1.PNG" alt="week-1-quiz">

<img src="../img/week1-quiz/2.PNG" alt="week-1-quiz">

<img src="../img/week1-quiz/3.PNG" alt="week-1-quiz">

<img src="../img/week1-quiz/4.PNG" alt="week-1-quiz">

<img src="../img/week1-quiz/5.PNG" alt="week-1-quiz">

<img src="../img/week1-quiz/6.PNG" alt="week-1-quiz">

<img src="../img/week1-quiz/7.PNG" alt="week-1-quiz">

<img src="../img/week1-quiz/8.PNG" alt="week-1-quiz">

<img src="../img/week1-quiz/9.PNG" alt="week-1-quiz">